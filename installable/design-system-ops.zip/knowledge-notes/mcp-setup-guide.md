---
name: mcp-setup-guide
type: knowledge
---

# MCP setup guide

**Knowledge note for Design System Ops**
**Auto-loaded by:** ai-component-description, context-engine-builder, system-health

---

## What MCP means for design systems

The Model Context Protocol (MCP) is the interface between AI agents and the data sources they consume. For design systems, MCP servers provide the bridge that lets AI tools read component definitions, token values, design specs, and system metadata without manual copy-paste or bespoke integrations.

A well-configured MCP setup turns a design system from a reference library into live infrastructure that AI agents query in real time. The agent asks "what components exist for navigation?" and the MCP server returns structured data from the system's actual component library — not a cached copy, not a summary, the real thing.

This matters because the quality of AI-generated design system output is directly proportional to the quality and freshness of the context the AI receives. An agent working from a six-month-old component list will generate output based on deprecated components and outdated APIs. An agent connected to the system via MCP works from the current state.

---

## The three-layer MCP architecture

Design systems benefit from a three-layer MCP architecture that separates concerns and prevents any single server from becoming a bottleneck.

### Layer 1: Design MCP (Figma or equivalent)

The design-side MCP server provides access to the design source of truth — component definitions, visual specs, and design tokens as they exist in the design tool.

**What it provides:**
- Component names, descriptions, and variant structures
- Design token values (colour, spacing, typography) as defined in the design tool
- Component layer hierarchy (for understanding composition)
- Component screenshots and visual references
- Page and frame structure for understanding component placement in context

**What it does not provide:**
- Code-level prop definitions (these live in the code, not the design)
- Behavioural specifications beyond what is visually representable
- Test coverage or implementation status
- Accessibility contract details (unless annotated in the design)

**Configuration considerations:**
- Authenticate with the design tool's API
- Scope access to the design system library file, not all company files
- Cache responses appropriately — design files change less frequently than code
- Handle rate limits gracefully (design tool APIs typically have request limits)

**Recommended server: Figma Console MCP from Southleft**

For Figma-based design systems, the [Figma Console MCP](https://github.com/southleft/figma-console-mcp) by Southleft is the recommended Layer 1 server. It provides read and write access to Figma through the Desktop Bridge plugin, including variable collections and component descriptions. The official Figma MCP server can also write to Figma (through its `use_figma` tool), but its read tools are scoped to the current selection — `get_variable_defs`, for example, returns only the variables a selected node uses, not whole collections — so collection-wide audits need the Console MCP.

This matters for Design System Ops because several skills close the loop when write access is available:
- `ai-component-description` writes generated descriptions directly into Figma components (visible in Dev Mode immediately)
- `figma-variable-audit` renames variables and adds missing modes directly in Figma after auditing
- `token-audit` creates missing semantic variables that the audit identified as gaps
- `codemod-generator` renames Figma variables alongside code-side token migrations
- `drift-detection` captures live screenshots from the current Figma state for visual comparison

The Figma Console MCP also provides design system-specific capabilities that the standard MCP does not: one-call design system summaries, component search by category, variable export as CSS/Sass/Tailwind/TypeScript, and the ability to execute arbitrary Figma Plugin API code.

Setup requires Figma Desktop with the Desktop Bridge plugin running. The connection persists across Figma restarts. For teams that cannot run Figma Desktop (e.g. CI/CD environments), the official Figma MCP server is the fallback, with the selection-scoped limits above.

### Layer 2: Design System MCP (the system's own server)

The design system's own MCP server provides access to the system's structured metadata — component manifests, metadata schemas, governance rules, decision trees, and context engine blueprints.

**What it provides:**
- Component inventory with categories, relationships, and status
- Structured JSON metadata for each component (props, behaviour, composition, accessibility)
- Governance rules as machine-readable constraints
- Decision trees for component selection
- Context engine blueprints (if generated)
- Token documentation with semantic intent
- AI-readiness assessments and system health findings

**What it does not provide:**
- Raw component source code (that is the code layer's responsibility)
- Live design specs (those come from Layer 1)
- Build and deployment status

**Configuration considerations:**
- The server reads from the `.ai/` directory structure generated by Design System Ops skills
- Version the served data alongside the codebase
- Support filtering (an agent requesting "all navigation components" should not receive the entire component inventory)
- Include versioning in responses so agents know what version of the system they are querying

### Layer 3: Code Connect (implementation bridge)

The code layer bridges the gap between design-side component names and code-side component implementations. It maps Figma components to their code equivalents, enabling agents to go from "this design uses a Button" to "import { Button } from '@system/components'".

**What it provides:**
- Mapping from design component names to code component paths
- Import statements and usage examples
- Prop mappings between design properties and code props
- Framework-specific integration details

**What it does not provide:**
- The full component source code (agents that need source code should read the file directly)
- Runtime behaviour or state management details
- Test specifications

**Configuration considerations:**
- Maintain the mapping as components are added or renamed
- Handle framework variations (a React component and a Vue component may map to the same Figma component)
- Include version alignment (which code version maps to which design version)

---

## Setting up the design system MCP server

The design system MCP server is the layer that Design System Ops directly supports. The skills in this product generate the structured data that the server serves.

### Data sources

The server reads from files generated by Design System Ops skills:

| Data source | Generated by | Location |
|---|---|---|
| Component inventory | `codebase-index` | `.ai/index/component-inventory.yml` |
| Component relationships | `codebase-index` | `.ai/index/component-relationships.yml` |
| Component metadata | `metadata-schema-generator` | `.ai/metadata/*.metadata.json` |
| Context engine blueprints | `context-engine-builder` | `.ai/context-engine/*.yml` |
| Governance rules | `governance-encoder` | `.ai/governance/rules/*.json` |
| Decision trees | `component-decision-tree` | `.ai/decision-trees/**/*.yml` |
| AI component descriptions | `ai-component-description` | Component description fields |

### Recommended server capabilities

An MCP server for a design system should support these query types:

**Component queries:**
- List all components (with optional category filter)
- Get a specific component's full metadata
- Get a component's relationships (uses, usedBy)
- Search components by intent or description

**Token queries:**
- List all tokens (with optional tier/category filter)
- Get a specific token's value and semantic intent
- Get tokens used by a specific component

**Governance queries:**
- Get all governance rules (with optional category/severity filter)
- Check a specific action against applicable rules
- Get the exception framework

**Decision queries:**
- Get the decision tree for a given intent category
- Get disambiguation guidance for a specific component pair

**System health queries:**
- Get the current AI-readiness status
- Get coverage metrics (metadata, descriptions, accessibility contracts)
- Get the context engine manifest

---

## Cross-layer integration

The three MCP layers are most powerful when they work together. Cross-layer queries let agents resolve questions that no single layer can answer alone.

### Design-to-code resolution

Agent question: "I see a Button in this Figma frame. What code component should I use?"

Resolution chain:
1. **Layer 1** (Design MCP): Identify the Figma component instance and its properties
2. **Layer 3** (Code Connect): Map the Figma component to the code component path and import
3. **Layer 2** (Design System MCP): Load the component's structured metadata for configuration guidance

### Intent-to-implementation resolution

Agent question: "I need a component for user notification. What should I use and how?"

Resolution chain:
1. **Layer 2** (Design System MCP): Traverse the notification decision tree to select the component
2. **Layer 2** (Design System MCP): Load the selected component's metadata for props and constraints
3. **Layer 1** (Design MCP): Get the visual spec for the selected component
4. **Layer 3** (Code Connect): Get the import path and usage example

### Consistency validation

Agent question: "Does this implementation match the design spec?"

Resolution chain:
1. **Layer 1** (Design MCP): Get the component's design properties
2. **Layer 3** (Code Connect): Get the implementation details
3. **Layer 2** (Design System MCP): Get the design-to-code contract and governance rules
4. Compare across all three layers and report discrepancies

---

## Integration with Design System Ops workflows

MCP servers are not just passive data providers — they participate in the workflows that Design System Ops skills orchestrate.

### During component creation

When a skill generates a new component:
1. The skill produces structured metadata and descriptions
2. The metadata is written to the `.ai/` directory
3. The MCP server picks up the new data (either via file watching or on next query)
4. Subsequent agent queries include the new component

### During audits

When a skill audits the system:
1. The skill queries the MCP server for current system state
2. The skill compares the current state against its quality criteria
3. The skill produces findings and recommendations
4. The findings can reference specific MCP-queryable data points for traceability

### During governance checks

When a skill checks governance compliance:
1. The skill loads governance rules from the MCP server
2. The skill evaluates the target against the rules
3. Violations reference the specific rule ID for traceability
4. The exception framework is available for context on permitted deviations

---

## Figma availability and graceful fallback

Before any skill attempts to call a Figma MCP tool, it must check whether the tool is actually available. Figma MCP tools fail for common, non-obvious reasons: the MCP server is not configured, the Desktop Bridge plugin is not running, no node is selected, or the file URL was not parsed correctly. These failures should not break the skill's workflow.

**Standard availability check pattern:**

Before calling any Figma tool, attempt a lightweight read operation (such as listing available tools or calling `figma_get_status`). If the call fails or returns an error:
1. Note in the output that Figma integration was not available for this run
2. Proceed with code-side data only
3. List what additional findings would be possible with Figma connected

**For skills where Figma is the primary input** (figma-variable-audit, ai-component-description):
- If Figma is not available, explain what the skill needs and how to set it up, rather than failing silently
- Offer to work from manually provided information (e.g. pasted component descriptions, exported variable JSON) as a fallback
- Frame it as: "This skill works best with Figma connected. Without it, I can still [what's possible] if you provide [what's needed]."

**For skills where Figma is optional enrichment** (most audit, validate, and document skills):
- Run the full workflow against code-side data
- Skip the Figma auto-pull steps with a brief note: "Figma integration not available — skipping design-side cross-reference"
- Do not treat missing Figma data as a finding or a problem — it is simply a data source that was not available

**Common Figma errors and what they mean:**
- "The node ID provided was invalid" — the URL was not parsed correctly, or the node does not exist in the file
- "You currently have nothing selected" — the Desktop Bridge plugin is running but no layer is selected in Figma
- "No element found with reference" — the Chrome-side MCP lost its DOM reference (page navigated or refreshed)
- Connection timeout or tool not found — the MCP server is not configured or Figma Desktop is not running

**Never retry a failed Figma call in a loop.** If the first call fails, note it, proceed without Figma, and let the user fix the connection for the next run.

---

## Common MCP setup pitfalls

**Stale data serving:** The MCP server serves cached data that does not reflect recent changes. Ensure the server either watches for file changes or refreshes on each request. Staleness windows should be documented.

**Overly broad access:** The server provides access to all company design files, not just the system library. Scope access to prevent agents from consuming data outside the design system boundary.

**Missing version alignment:** The design layer and code layer are at different versions, and the MCP server does not expose this. Always include version metadata in responses so agents can detect misalignment.

**No error handling:** The server returns empty results when data is missing, and the agent interprets this as "no components exist" rather than "data not found." Distinguish between empty results (the query returned no matches) and missing data (the data source is unavailable).

**Token budget exhaustion:** The server returns the entire component inventory when an agent only needs one component. Support filtering and pagination to keep responses within token budgets.

---

## Measuring MCP effectiveness

Track these metrics to assess whether the MCP setup is serving agents well:

- **Query success rate**: What percentage of MCP queries return useful results? Low success rates indicate data gaps or query pattern mismatches.
- **Data freshness**: What is the average age of served data relative to the source? Track this per data source.
- **Cross-layer resolution rate**: What percentage of multi-layer queries complete successfully across all three layers?
- **Agent error rate with MCP vs without**: Compare the quality of agent output when MCP is available vs when it falls back to other context sources. The delta quantifies MCP's value.
- **Token efficiency**: Average token count per MCP response. Monitor for bloat over time as the system grows.
